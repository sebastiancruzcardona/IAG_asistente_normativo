# Guía de uso del asistente normativo

## Interacción con  el asistente


El   sistema funciona mediante una interfaz de chat en la que el usuario puede formular preguntas relacionadas con información y procedimientos del ámbito jurídico. Para realizar una consulta, ingrese a la interfaz de entrada y escriba la solicitud de forma clara, proporcionando los datos necesarios según el tipo de consulta.

El asistente analiza la solicitud para identificar su categoría, tipo de consulta y la información disponible. Cuando los datos proporcionados no son suficientes para atender la solicitud, puede solicitar información adicional antes de continuar.

## Consulta del estado de un proceso

Si requiere consultar el estado de un proceso judicial, incluya el código del proceso en la solicitud. El código debe estar conformado por la letra P, seguida de un guion y 11 dígitos, por ejemplo: P-20210010001.

Una consulta puede formularse directamente en el chat, por ejemplo: "¿Cómo va el proceso P-20210010001?". Si se proporciona un código válido, el sistema puede consultar el registro correspondiente y devolver la información disponible sobre su estado.

Si se solicita el estado de un proceso sin proporcionar su código, el sistema solicitará el código del proceso antes de realizar la consulta.

La consulta de procesos es de solo lectura. El sistema no permite crear, modificar, actualizar, alterar o eliminar registros de procesos mediante esta interfaz.

## Información y alcance

El asistente utiliza la información proporcionada en la solicitud para determinar cómo atenderla. No debe asumirse que una respuesta contiene información que no haya sido proporcionada o recuperada mediante las fuentes disponibles.

Las solicitudes que se encuentren fuera del alcance del sistema pueden ser rechazadas o requerir revisión humana. Cuando una solicitud necesite información adicional, el asistente indicará los datos que deben proporcionarse para continuar.
