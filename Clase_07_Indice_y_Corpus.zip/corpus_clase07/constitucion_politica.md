# CONSTITUCION POLITICA DE COLOMBIA

## Artículo 1

Colombia   es un Estado social de derecho, organizado en forma de República unitaria, descentralizada, con autonomía de sus entidades territoriales, democrática, participativa y pluralista, fundada en el respeto de la dignidad humana, en el trabajo y la solidaridad de las personas que la integran y en la prevalencia del interés general.

## Artículo 2

Son fines esenciales del Estado: servir a la comunidad, promover la prosperidad general y garantizar la efectividad de los principios, derechos y deberes consagrados en la Constitución; facilitar la participación de todos en las decisiones que los afectan y en la vida económica, política, administrativa y cultural de la Nación; defender la independencia nacional, mantener la integridad territorial y asegurar la convivencia pacifica y la vigencia de un orden justo.


Las autoridades de la República están instituidas para proteger a todas las personas
residentes en Colombia, en su vida, honra, bienes, creencias, y demás derechos y
libertades, y para asegurar el cumplimiento de los deberes sociales del Estado y de los particulares.

## Artículo 3

La soberanía reside exclusivamente en el pueblo, del cual emana el poder público. El pueblo la ejerce en forma directa o por medio de sus representantes, en los términos que la Constitución establece.

## Artículo 4

La Constitución es norma de normas. En todo caso de incompatibilidad entre la Constitución y la ley u otra norma jurídica, se aplicarán las disposiciones
constitucionales.

Es deber   de los nacionales y de los extranjeros en Colombia acatar la Constitución y las leyes, y respetar y obedecer a las autoridades.

## Artículo 5

El Estado reconoce, sin discriminación alguna, la primacía de los derechos
inalienables de la persona y ampara a la familia como institución básica de la sociedad.

## Artículo 6

Los particulares sólo son responsables ante las autoridades por infringir la
Constitución y las leyes. Los servidores públicos lo son por la misma causa y por
omisión o extralimitación en el ejercicio de sus funciones.

## Artículo 7

El Estado reconoce y protege la diversidad étnica y cultural de la Nación
colombiana.

## Artículo 8

Es obligación del Estado y de las personas proteger las riquezas culturales y
naturales de la Nación.

## Artículo 9

Las relaciones exteriores del Estado se fundamentan en la soberanía
nacional, en el respeto a la autodeterminación de los pueblos y en el reconocimiento de
los principios del derecho internacional aceptados por Colombia.
De igual manera, la política exterior de Colombia se orientará hacia la
integración latinoamericana y del Caribe.

## Artículo 10

El castellano es el idioma oficial de Colombia. Las lenguas y dialectos de los
grupos étnicos son también oficiales en sus territorios. La enseñanza que se imparta
en las comunidades con tradiciones lingüísticas propias será bilingüe.

## Artículo 11

El derecho a la vida es inviolable. No habrá pena de muerte.

## Artículo 12

Nadie será sometido a desaparición forzada, a torturas ni a tratos o penas
crueles, inhumanos o degradantes.

## Artículo 13

Todas las personas nacen libres e iguales ante la ley, recibirán la misma
protección y trato de las autoridades y gozarán de los mismos derechos, libertades y
oportunidades sin ninguna discriminación por razones de sexo, raza, origen nacional o
familiar, lengua, religión, opinión política o filosófica.
El Estado promoverá las condiciones para que la igualdad sea real y efectiva y adoptara
medidas en favor de grupos discriminados o marginados.
El Estado protegerá especialmente a aquellas personas que por su condición
económica, física o mental, se encuentren en circunstancia de debilidad manifiesta y
sancionará los abusos o maltratos que contra ellas se cometan.

## Artículo 14

Toda persona tiene derecho al reconocimiento de su personalidad jurídica.

## Artículo 15

Todas las personas tienen derecho a su intimidad personal y familiar y a su
buen nombre, y el Estado debe respetarlos y hacerlos respetar. De igual modo, tienen
derecho a conocer, actualizar y rectificar las informaciones que se hayan recogido sobre
ellas en bancos de datos y en archivos de entidades públicas y privadas.
En la recolección, tratamiento y circulación de datos se respetarán la libertad y demás
garantías consagradas en la Constitución.
La correspondencia y demás formas de comunicación privada son inviolables. Sólo
pueden ser interceptadas o registradas mediante orden judicial, en los casos y con las
formalidades que establezca la ley.
Para efectos tributarios o judiciales y para los casos de inspección, vigilancia e
intervención del Estado podrá exigirse la presentación de libros de contabilidad y demás
documentos privados, en los términos que señale la ley.

## Artículo 16

Todas las personas tienen derecho al libre desarrollo de su personalidad
sin más limitaciones que las que imponen los derechos de los demás y el orden jurídico.

## Artículo 17

Se prohiben la esclavitud, la servidumbre y la trata de seres humanos en
todas sus formas.

## Artículo 18

Se garantiza la libertad de conciencia. Nadie será molestado por razón de sus
convicciones o creencias ni compelido a revelarlas ni obligado a actuar contra su
conciencia.

## Artículo 19

Se garantiza la libertad de cultos. Toda persona tiene derecho a profesar
libremente su religión y a difundirla en forma individual o colectiva.
Todas las confesiones religiosas e iglesias son igualmente libres ante la ley.

## Artículo 20

Se garantiza a toda persona la libertad de expresar y difundir su
pensamiento y opiniones, la de informar y recibir información veraz e imparcial, y la de
fundar medios masivos de comunicación.
Estos son libres y tienen responsabilidad social. Se garantiza el derecho a la
rectificación en condiciones de equidad. No habrá censura.

## Artículo 21

Se garantiza el derecho a la honra. La ley señalará la forma de su
protección.

## Artículo 22

La paz es un derecho y un deber de obligatorio cumplimiento.

## Artículo 23

Toda persona tiene derecho a presentar peticiones respetuosas a las
autoridades por motivos de interés general o particular y a obtener pronta resolución. El
legislador podrá reglamentar su ejercicio ante organizaciones privadas para garantizar
los derechos fundamentales.

## Artículo 24

Todo colombiano, con las limitaciones que establezca la ley, tiene derecho
a circular libremente por el territorio nacional, a entrar y salir de él, y a permanecer y
residenciarse en Colombia.

## Artículo 25

El trabajo es un derecho y una obligación social y goza, en todas sus
modalidades, de la especial protección del Estado. Toda persona tiene derecho a un
trabajo en condiciones dignas y justas.

## Artículo 26

Toda persona es libre de escoger profesión u oficio. La ley podrá exigir
títulos de idoneidad. Las autoridades competentes inspeccionaran y vigilaran el ejercicio
de las profesiones. Las ocupaciones, artes y oficios que no exijan formación académica
son de libre ejercicio, salvo aquellas que impliquen un riesgo social.
Las profesiones legalmente reconocidas pueden organizarse en colegios. La estructura
interna y el funcionamiento de estos deberán ser democráticos.
La ley podrá asignarles funciones públicas y establecer los debidos controles.

## Artículo 27

El Estado garantiza las libertades de enseñanza, aprendizaje, investigación
y cátedra.

## Artículo 28

Toda persona es libre. Nadie puede ser molestado en su persona o familia,
ni reducido a prisión o arresto, ni detenido, ni su domicilio registrado, sino en virtud de
mandamiento escrito de autoridad judicial competente, con las formalidades legales y
por motivo previamente definido en la ley.
La persona detenida preventivamente será puesta a disposición del juez competente
dentro de las treinta y seis horas siguientes, para que éste adopte la decisión
correspondiente en el término que establezca la ley. En ningún caso podrá haber
detención, prisión ni arresto por deudas, ni penas y medidas de seguridad
imprescriptibles.

## Artículo 29

El debido proceso se aplicará a toda clase de actuaciones judiciales y
administrativas.
Nadie podrá ser juzgado sino conforme a leyes preexistentes al acto que se le imputa,
ante juez o tribunal competente y con observancia de la plenitud de las formas propias
de cada juicio.
En materia penal, la ley permisiva o favorable, aun cuando sea posterior, se aplicará de
preferencia a la restrictiva o desfavorable.
Toda persona se presume inocente mientras no se la haya declarado judicialmente
culpable. Quien sea sindicado tiene derecho a la defensa y a la asistencia de un
abogado escogido por el, o de oficio, durante la investigación y el juzgamiento; a un
debido proceso publico sin dilaciones injustificadas; a presentar pruebas y a controvertir
las que se alleguen en su contra; a impugnar la sentencia condenatoria, y a no ser
juzgado dos veces por el mismo hecho.
Es nula, de pleno derecho, la prueba obtenida con violación del debido proceso.

## Artículo 30

Quien estuviere privado de su libertad, y creyere estarlo ilegalmente, tiene
derecho a invocar ante cualquier autoridad judicial, en todo tiempo, por si o por
interpuesta persona, el Habeas Corpus, el cual debe resolverse en el término de treinta
y seis horas.

## Artículo 31

Toda sentencia judicial podrá ser apelada o consultada, salvo las
excepciones que consagre la ley.
El superior no podrá agravar la pena impuesta cuando el condenado sea apelante
único.

## Artículo 32

El delincuente sorprendido en flagrancia podrá ser aprehendido y llevado
ante el juez por cualquier persona. Si los agentes de la autoridad lo persiguieren y se
refugiare en su propio domicilio, podrán penetrar en él, para el acto de la aprehensión;
si se acogiere a domicilio ajeno, deberá preceder requerimiento al morador.

## Artículo 33

Nadie podrá ser obligado a declarar contra si mismo o contra su cónyuge,
compañero permanente o parientes dentro del cuarto grado de consanguinidad,
segundo de afinidad o primero civil.

## Artículo 34

Se prohiben las penas de destierro, prisión perpetua y confiscación.
No obstante, por sentencia judicial, se declarará extinguido el dominio sobre los bienes
adquiridos mediante enriquecimiento ilícito, en perjuicio del Tesoro Público o con grave
deterioro de la moral social.

## Artículo 35

Se prohibe la extradición de colombianos por nacimiento. No se concederá
la extradición de extranjeros por delitos políticos o de opinión.
Los colombianos que hayan cometido delitos en el exterior, considerados como tales en
la legislación nacional, serán procesados y juzgados en Colombia.

## Artículo 36

Se reconoce el derecho de asilo en los términos previstos en la ley.

## Artículo 37

Toda parte del pueblo puede reunirse y manifestarse pública y
pacíficamente. Sólo la ley podrá establecer de manera expresa los casos en los cuales
se podrá limitar el ejercicio de este derecho.

## Artículo 38

Se garantiza el derecho de libre asociación para el desarrollo de las
distintas actividades que las personas realizan en sociedad.

## Artículo 39

Los trabajadores y empleadores tienen derecho a constituir sindicatos o
asociaciones, sin intervención del Estado. Su reconocimiento jurídico se producirá con
la simple inscripción del acta de constitución.
La estructura interna y el funcionamiento de los sindicatos y organizaciones sociales y
gremiales se sujetarán al orden legal y a los principios democráticos.
La cancelación o la suspensión de la personería jurídica sólo procede por vía judicial.
Se reconoce a los representantes sindicales el fuero y las demás garantías necesarias
para el cumplimiento de su gestión.
No gozan del derecho de asociación sindical los miembros de la Fuerza Pública.

## Artículo 40

Todo ciudadano tiene derecho a participar en la conformación, ejercicio y
control del poder político. Para hacer efectivo este derecho puede:
1. Elegir y ser elegido.
2. Tomar parte en elecciones, plebiscitos, referendos, consultas populares y otras
formas de participación democrática.
3. Constituir partidos, movimientos y agrupaciones políticas sin limitación alguna: formar
parte de ellos libremente y difundir sus ideas y programas.
4. Revocar el mandato de los elegidos en los casos y en la forma que establecen la
Constitución y la ley.
5. Tener iniciativa en las corporaciones públicas.
6. Interponer acciones públicas en defensa de la Constitución y de la ley.
7. Acceder al desempeño de funciones y cargos públicos, salvo los colombianos, por
nacimiento o por adopción, que tengan doble nacionalidad. La ley reglamentará esta
excepción y determinará los casos a los cuales ha de aplicarse.
Las autoridades garantizarán la adecuada y efectiva participación de la mujer en los
niveles decisorios de la Administración Pública.

## Artículo 41

En todas las instituciones de educación, oficiales o privadas, serán
obligatorios el estudio de la Constitución y la Instrucción Cívica. Así mismo se
fomentarán prácticas democráticas para el aprendizaje de los principios y valores de
la participación ciudadana. El Estado divulgará la Constitución.
